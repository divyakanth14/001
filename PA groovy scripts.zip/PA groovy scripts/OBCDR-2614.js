import java.util.Base64;
import javax.xml.bind.DatatypeConverter; 
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException; 
import java.security.cert.CertificateEncodingException; 
import java.security.cert.X509Certificate; 
import com.fasterxml.jackson.databind.JsonNode; 
import com.fasterxml.jackson.databind.ObjectMapper; 
import java.io.ByteArrayInputStream; 
import java.security.cert.CertificateException; 
import java.security.cert.CertificateFactory; 
import java.io.UnsupportedEncodingException; 
import java.net.URLDecoder;
import groovy.json.JsonSlurper;
import  java. util.*;

import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;

println "Enter Script";


	

def cdr_arrangement_id = getRequestParameter(exc?.request, "cdr_arrangement_id");
println("arrange: " +cdr_arrangement_id);
def client_id = getRequestParameter(exc?.request, "client_id");
println("client: " +client_id);


def statusCode = exc?.response?.statusCode;
println("status1: "+statusCode);

if(exc?.response)
	{
		
        try{
               
			   println "Start---------------"

               URL baseUrl = new URL("https://vpc-endpoint-alb.prod.cdr.gsb-aws.com.au:443/authentication/adr-revoke");
               def conn = baseUrl.openConnection();
               conn.setRequestMethod("POST");
               conn.setRequestProperty("x-cdr-arrangement-id" , cdr_arrangement_id);
               conn.setRequestProperty("x-client-id" , client_id);
			   
			   println conn.getResponseCode();
               
			   
		

            }
        catch(IOException e)

             {
                 println ("THROWEXCEPTION "+e);
             }
			 
			 pass();
	}

pass()


String getRequestParameter(def request, def paramName)
{
  def postParams = request?.getPostParams();
  if(postParams == null)
    return null;

  if(!postParams.containsKey(paramName))
    return null;

  return postParams.get(paramName)[0];
}